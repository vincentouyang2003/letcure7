package ict.mgame.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {

    // 声明控件
    private EditText etCurrentPass;       // 原密码输入框
    private EditText etNewPass;           // 新密码输入框
    private EditText etConfirmNewPass;    // 确认新密码输入框
    private Button btnSavePass;           // 保存按钮
    private Button btnBack;               // 返回按钮
    private SharedPreferences prefs;      // 用于存储用户密码

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 加载修改密码布局（确保res/layout/change_password.xml存在）
        setContentView(R.layout.change_password);

        // 初始化控件
        initViews();

        // 初始化SharedPreferences（与登录页共用同一存储文件）
        prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);

        // 保存修改按钮点击事件：验证并修改密码
        btnSavePass.setOnClickListener(v -> validateAndChangePassword());

        // 返回按钮点击事件：关闭当前页面，回到游戏页
        btnBack.setOnClickListener(v -> finish());
    }

    // 初始化所有控件（与布局文件中的ID对应）
    private void initViews() {
        etCurrentPass = findViewById(R.id.etCurrentPass);
        etNewPass = findViewById(R.id.etNewPass);
        etConfirmNewPass = findViewById(R.id.etConfirmNewPass);
        btnSavePass = findViewById(R.id.btnSavePass);
        btnBack = findViewById(R.id.btnBack);
    }

    // 验证输入并修改密码
    private void validateAndChangePassword() {
        // 获取输入的密码
        String currentPass = etCurrentPass.getText().toString().trim();
        String newPass = etNewPass.getText().toString().trim();
        String confirmNewPass = etConfirmNewPass.getText().toString().trim();

        // 1. 验证所有输入不为空
        if (currentPass.isEmpty() || newPass.isEmpty() || confirmNewPass.isEmpty()) {
            showAlert("Error", "Please fill in all fields!");
            return;
        }

        // 2. 验证原密码是否正确（与SharedPreferences中存储的密码比对）
        String savedPass = prefs.getString("password", "");
        if (!currentPass.equals(savedPass)) {
            showAlert("Error", "Current password is incorrect!");
            return;
        }

        // 3. 验证新密码长度至少6位
        if (newPass.length() < 6) {
            showAlert("Error", "New password must be at least 6 characters!");
            return;
        }

        // 4. 验证新密码与确认密码一致
        if (!newPass.equals(confirmNewPass)) {
            showAlert("Error", "New passwords do not match!");
            return;
        }

        // 5. 所有验证通过，更新密码到SharedPreferences
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("password", newPass);
        editor.apply(); // 异步保存

        // 6. 提示修改成功，并跳转到登录页面（清除历史页面，强制重新登录）
        showAlert("Success", "Password changed! Please log in again.");

        // 跳转登录页，并清除所有之前的页面（任务栈）
        Intent intent = new Intent(ChangePasswordActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish(); // 关闭当前修改密码页面
    }

    // 显示提示对话框
    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}