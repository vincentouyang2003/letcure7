package ict.mgame.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // 声明控件
    private EditText etUsername, etPassword, etConfirmPassword;
    private TextView tvConfirmPassword;
    private Button btnAction, btnToggle;
    private SharedPreferences prefs;
    private boolean isLoginMode = true; // 登录/注册模式标记

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login); // 加载login.xml布局

        // 初始化控件（与布局ID严格对应）
        initViews();

        // 初始化SharedPreferences
        prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);

        // 登录/注册按钮点击事件
        btnAction.setOnClickListener(v -> {
            if (isLoginMode) {
                handleLogin();
            } else {
                handleSignUp();
            }
        });

        // 切换模式按钮点击事件
        btnToggle.setOnClickListener(v -> toggleMode());
    }

    // 初始化所有控件
    private void initViews() {
        etUsername = findViewById(R.id.etUsername);       // 匹配布局中的etUsername
        etPassword = findViewById(R.id.etPassword);       // 匹配布局中的etPassword
        etConfirmPassword = findViewById(R.id.etConfirmPassword); // 匹配布局中的etConfirmPassword
        tvConfirmPassword = findViewById(R.id.tvConfirmPassword); // 匹配布局中的tvConfirmPassword
        btnAction = findViewById(R.id.btnAction);         // 匹配布局中的btnAction
        btnToggle = findViewById(R.id.btnToggle);         // 匹配布局中的btnToggle
    }

    // 切换登录/注册模式
    private void toggleMode() {
        isLoginMode = !isLoginMode;
        if (isLoginMode) {
            // 切换到登录模式
            btnAction.setText("Login");
            btnToggle.setText("Create new account");
            tvConfirmPassword.setVisibility(View.GONE);
            etConfirmPassword.setVisibility(View.GONE);
        } else {
            // 切换到注册模式
            btnAction.setText("Sign Up");
            btnToggle.setText("Already have an account? Login");
            tvConfirmPassword.setVisibility(View.VISIBLE);
            etConfirmPassword.setVisibility(View.VISIBLE);
        }
        // 清空输入
        etUsername.setText("");
        etPassword.setText("");
        etConfirmPassword.setText("");
    }

    // 处理登录逻辑
    private void handleLogin() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // 验证输入
        if (username.isEmpty() || password.isEmpty()) {
            showAlert("Error", "Please fill all fields!");
            return;
        }

        // 获取存储的用户信息
        String savedUser = prefs.getString("username", "");
        String savedPass = prefs.getString("password", "");

        // 验证账号密码
        if (username.equals(savedUser) && password.equals(savedPass)) {
            // 登录成功，跳转到Bingo游戏
            startActivity(new Intent(this, MainActivity.class));
            finish(); // 关闭登录页，防止返回
        } else {
            showAlert("Failed", "Incorrect username or password!");
        }
    }

    // 处理注册逻辑
    private void handleSignUp() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPass = etConfirmPassword.getText().toString().trim();

        // 验证输入
        if (username.isEmpty() || password.isEmpty() || confirmPass.isEmpty()) {
            showAlert("Error", "Please fill all fields!");
            return;
        }
        if (!password.equals(confirmPass)) {
            showAlert("Error", "Passwords do not match!");
            return;
        }
        if (password.length() < 6) {
            showAlert("Error", "Password must be at least 6 characters!");
            return;
        }

        // 保存用户信息
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("username", username);
        editor.putString("password", password);
        editor.apply();

        // 注册成功提示
        showAlert("Success", "Account created! Please login.");
        toggleMode(); // 切回登录模式
    }

    // 显示提示对话框
    private void showAlert(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}