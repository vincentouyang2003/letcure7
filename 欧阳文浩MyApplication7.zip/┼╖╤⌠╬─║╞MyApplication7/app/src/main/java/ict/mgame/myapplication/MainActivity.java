package ict.mgame.myapplication;



import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    // Bingo卡片格子（5列，每列5个格子）
    private TextView[] bColumn = new TextView[5];
    private TextView[] iColumn = new TextView[5];
    private TextView[] nColumn = new TextView[4]; // 排除中间FREE格
    private TextView[] gColumn = new TextView[5];
    private TextView[] oColumn = new TextView[5];

    // 叫号相关
    private TextView tvCurrentNumber; // 显示当前叫号
    private Button btnStartGame;      // 开始游戏按钮
    private Handler handler;          // 定时器
    private Set<Integer> calledNumbers = new HashSet<>(); // 已叫过的数字（避免重复）
    private boolean isGameRunning = false; // 游戏是否正在进行

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 初始化控件
        initViews();
        initColumns();

        // 初始化定时器
        handler = new Handler(Looper.getMainLooper());

        // 新游戏按钮：生成新卡片并重置状态
        Button btnNewGame = findViewById(R.id.btnNewGame);
        btnNewGame.setOnClickListener(v -> resetGame());

        // 修改密码按钮
        Button btnChangePass = findViewById(R.id.btnChangePass);
        btnChangePass.setOnClickListener(v -> {
            startActivity(new Intent(this, ChangePasswordActivity.class));
        });

        // 开始游戏按钮：控制叫号开始/停止
        btnStartGame.setOnClickListener(v -> {
            if (isGameRunning) {
                stopGame();
            } else {
                startGame();
            }
        });
    }

    // 初始化所有控件
    private void initViews() {
        tvCurrentNumber = findViewById(R.id.tvCurrentNumber);
        btnStartGame = findViewById(R.id.btnStartGame);
    }

    // 初始化Bingo各列格子
    private void initColumns() {
        // B列（1-15）
        bColumn[0] = findViewById(R.id.b0);
        bColumn[1] = findViewById(R.id.b1);
        bColumn[2] = findViewById(R.id.b2);
        bColumn[3] = findViewById(R.id.b3);
        bColumn[4] = findViewById(R.id.b4);

        // I列（16-30）
        iColumn[0] = findViewById(R.id.i0);
        iColumn[1] = findViewById(R.id.i1);
        iColumn[2] = findViewById(R.id.i2);
        iColumn[3] = findViewById(R.id.i3);
        iColumn[4] = findViewById(R.id.i4);

        // N列（31-45，排除中间FREE格）
        nColumn[0] = findViewById(R.id.n0);
        nColumn[1] = findViewById(R.id.n1);
        nColumn[2] = findViewById(R.id.n3); // 跳过n2（FREE格）
        nColumn[3] = findViewById(R.id.n4);

        // G列（46-60）
        gColumn[0] = findViewById(R.id.g0);
        gColumn[1] = findViewById(R.id.g1);
        gColumn[2] = findViewById(R.id.g2);
        gColumn[3] = findViewById(R.id.g3);
        gColumn[4] = findViewById(R.id.g4);

        // O列（61-75）
        oColumn[0] = findViewById(R.id.o0);
        oColumn[1] = findViewById(R.id.o1);
        oColumn[2] = findViewById(R.id.o2);
        oColumn[3] = findViewById(R.id.o3);
        oColumn[4] = findViewById(R.id.o4);
    }

    // 生成新的Bingo卡片
    private void generateNewBingoCard() {
        generateColumnNumbers(bColumn, 1, 15);    // B列：1-15
        generateColumnNumbers(iColumn, 16, 30);   // I列：16-30
        generateColumnNumbers(nColumn, 31, 45);   // N列：31-45
        generateColumnNumbers(gColumn, 46, 60);   // G列：46-60
        generateColumnNumbers(oColumn, 61, 75);   // O列：61-75
    }

    // 为列生成随机数字（不重复）
    private void generateColumnNumbers(TextView[] column, int min, int max) {
        List<Integer> numbers = new ArrayList<>();
        for (int i = min; i <= max; i++) numbers.add(i);
        Collections.shuffle(numbers, new Random());

        for (int i = 0; i < column.length; i++) {
            column[i].setText(String.valueOf(numbers.get(i)));
            column[i].setSelected(false);
            column[i].setBackgroundResource(R.drawable.bingo_cell_border);
            column[i].setTextColor(getResources().getColor(R.color.textPrimary));
        }
    }

    // 开始游戏：每3秒生成一个随机数
    private void startGame() {
        isGameRunning = true;
        btnStartGame.setText("STOP GAME");
        tvCurrentNumber.setText("--");
        calledNumbers.clear(); // 清空已叫数字
        generateNewBingoCard(); // 生成新卡片
        startCallingNumbers(); // 开始叫号
    }

    // 停止游戏
    private void stopGame() {
        isGameRunning = false;
        btnStartGame.setText("START GAME");
        handler.removeCallbacksAndMessages(null); // 停止定时器
    }

    // 重置游戏（新游戏）
    private void resetGame() {
        stopGame();
        generateNewBingoCard();
        tvCurrentNumber.setText("--");
        calledNumbers.clear();
    }

    // 每3秒生成一个1-75的随机数（不重复）
    private void startCallingNumbers() {
        handler.postDelayed(() -> {
            if (!isGameRunning) return;

            // 生成1-75的随机数（不重复）
            int number;
            do {
                number = new Random().nextInt(75) + 1; // 1-75
            } while (calledNumbers.contains(number));

            calledNumbers.add(number);
            tvCurrentNumber.setText(String.valueOf(number)); // 显示当前叫号

            // 自动标记卡片上的对应数字
            markNumberOnCard(number);

            // 检测是否达成Bingo
            if (checkBingo()) {
                new AlertDialog.Builder(this)
                        .setTitle("BINGO!")
                        .setMessage("Congratulations! You won!")
                        .setPositiveButton("OK", (dialog, which) -> stopGame())
                        .show();
                return;
            }

            // 继续下一次叫号
            startCallingNumbers();
        }, 3000); // 3秒延迟
    }

    // 在卡片上标记对应数字（如果存在）
    private void markNumberOnCard(int target) {
        // 检查B列（1-15）
        for (TextView tv : bColumn) {
            if (Integer.parseInt(tv.getText().toString()) == target) {
                setNumberSelected(tv, true);
                return;
            }
        }

        // 检查I列（16-30）
        for (TextView tv : iColumn) {
            if (Integer.parseInt(tv.getText().toString()) == target) {
                setNumberSelected(tv, true);
                return;
            }
        }

        // 检查N列（31-45）
        for (TextView tv : nColumn) {
            if (Integer.parseInt(tv.getText().toString()) == target) {
                setNumberSelected(tv, true);
                return;
            }
        }

        // 检查G列（46-60）
        for (TextView tv : gColumn) {
            if (Integer.parseInt(tv.getText().toString()) == target) {
                setNumberSelected(tv, true);
                return;
            }
        }

        // 检查O列（61-75）
        for (TextView tv : oColumn) {
            if (Integer.parseInt(tv.getText().toString()) == target) {
                setNumberSelected(tv, true);
                return;
            }
        }
    }

    // 设置数字选中状态
    private void setNumberSelected(TextView tv, boolean selected) {
        tv.setSelected(selected);
        if (selected) {
            tv.setBackgroundResource(R.drawable.bingo_cell_selected);
            tv.setTextColor(getResources().getColor(R.color.textWhite));
        } else {
            tv.setBackgroundResource(R.drawable.bingo_cell_border);
            tv.setTextColor(getResources().getColor(R.color.textPrimary));
        }
    }

    // 手动点击标记数字（保留手动标记功能）
    public void onNumberClick(View view) {
        TextView tv = (TextView) view;
        setNumberSelected(tv, !tv.isSelected());
        // 手动标记后检查是否Bingo
        if (checkBingo()) {
            new AlertDialog.Builder(this)
                    .setTitle("BINGO!")
                    .setMessage("Congratulations! You won!")
                    .setPositiveButton("OK", (dialog, which) -> stopGame())
                    .show();
        }
    }

    // 检测是否达成Bingo（一行、一列或对角线全选中）
    private boolean checkBingo() {
        // 检查行（共5行）
        if (checkRow(0) || checkRow(1) || checkRow(2) || checkRow(3) || checkRow(4)) {
            return true;
        }

        // 检查列（共5列）
        if (checkColumn(bColumn) || checkColumn(iColumn) || checkColumn(nColumn) || checkColumn(gColumn) || checkColumn(oColumn)) {
            return true;
        }

        // 检查对角线
        if (checkDiagonal1() || checkDiagonal2()) {
            return true;
        }

        return false;
    }

    // 检查某一行是否全选中
    private boolean checkRow(int rowIndex) {
        // 行索引：0-4（对应5行）
        return bColumn[rowIndex].isSelected() &&
                iColumn[rowIndex].isSelected() &&
                (rowIndex == 2 || nColumn[rowIndex].isSelected()) && // 第3行中间是FREE格（默认选中）
                gColumn[rowIndex].isSelected() &&
                oColumn[rowIndex].isSelected();
    }

    // 检查某一列是否全选中
    private boolean checkColumn(TextView[] column) {
        for (TextView tv : column) {
            if (!tv.isSelected()) return false;
        }
        return true;
    }

    // 检查对角线1（左上到右下）
    private boolean checkDiagonal1() {
        return bColumn[0].isSelected() &&
                iColumn[1].isSelected() &&
                gColumn[3].isSelected() &&
                oColumn[4].isSelected();
        // 中间是FREE格（默认选中，无需检查）
    }

    // 检查对角线2（右上到左下）
    private boolean checkDiagonal2() {
        return oColumn[0].isSelected() &&
                gColumn[1].isSelected() &&
                iColumn[3].isSelected() &&
                bColumn[4].isSelected();
        // 中间是FREE格（默认选中，无需检查）
    }

    // 页面销毁时停止定时器（避免内存泄漏）
    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}